
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '@/types/clinical';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

// Remove local User interface and use imported type
interface AuthContextType {
  currentUser: User | null;
  login: (username: string, password: string) => Promise<void>;
  register: (userData: RegisterUserData) => Promise<User>;
  logout: () => void;
  hasPermission: (permission: string) => boolean;
  canEditNotes: () => boolean;
  canViewBilling: () => boolean;
  isLoading: boolean;
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;
}

interface RegisterUserData {
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  role: 'admin' | 'supervisor' | 'clinician';
  password: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demonstration - in production this would be managed by backend
let mockUsers: User[] = [
  {
    id: '750e8400-e29b-41d4-a716-446655440001',
    username: 'admin',
    email: 'admin@clinic.com',
    firstName: 'John',
    lastName: 'Admin',
    role: 'admin',
    department: 'Administration',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    password: 'admin123'
  },
  {
    id: '750e8400-e29b-41d4-a716-446655440002',
    username: 'clinician',
    email: 'clinician@clinic.com',
    firstName: 'Dr. Sarah',
    lastName: 'Thompson',
    role: 'clinician',
    department: 'Physiotherapy',
    license: 'PT12345',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    password: 'clinician123'
  },
  {
    id: '750e8400-e29b-41d4-a716-446655440003',
    username: 'supervisor',
    email: 'supervisor@clinic.com',
    firstName: 'Dr. Michael',
    lastName: 'Wilson',
    role: 'supervisor',
    department: 'Clinical Services',
    license: 'MD67890',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    password: 'supervisor123'
  },
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Load users from localStorage if available
    const storedUsers = localStorage.getItem('mockUsers');
    if (storedUsers) {
      mockUsers = JSON.parse(storedUsers);
    }
    
    // Check for stored user session
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (username: string, password: string): Promise<void> => {
    setIsLoading(true);
    try {
      // Mock authentication - in real app, this would be an API call
      const user = mockUsers.find(u => u.username === username);
      if (user && user.password && password === user.password) {
        setCurrentUser(user);
        localStorage.setItem('currentUser', JSON.stringify(user));
      } else {
        throw new Error('Invalid credentials');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: RegisterUserData): Promise<User> => {
    setIsLoading(true);
    try {
      // Check if user already exists in mock data
      const existingUser = mockUsers.find(u => u.email === userData.email || u.username === userData.username);
      if (existingUser) {
        throw new Error('User with this email or username already exists');
      }

      // Create new user with required fields
      const newUser: User = {
        id: crypto.randomUUID(),
        username: userData.username,
        email: userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        role: userData.role,
        department: userData.role === 'clinician' ? 'Physiotherapy' : 'Administration',
        isActive: true,
        createdAt: new Date().toISOString(),
        license: userData.role === 'clinician' ? 'PT12345' : undefined,
      };

      // Add to mock users array for immediate UI update
      mockUsers.push(newUser);
      
      // Try to create user in Supabase database
      try {
        const { data: dbUser, error: dbError } = await supabase
          .from('users')
          .insert({
            email: userData.email,
            first_name: userData.firstName,
            last_name: userData.lastName,
            username: userData.username,
            role: userData.role,
            initials: newUser.initials,
            clinician_color: newUser.clinicianColor,
            is_active: true
          })
          .select()
          .single();

        if (dbError) {
          console.warn('Supabase database error:', dbError.message);
          toast.warning('User created locally. Database integration pending.');
        } else {
          console.log('User created in Supabase database:', dbUser.id);
          // Update the newUser with the actual database ID
          newUser.id = dbUser.id;
          toast.success('User registered successfully!');
        }
      } catch (supabaseError) {
        console.warn('Supabase not available:', supabaseError);
        toast.success('User registered locally. Database integration pending.');
      }
      
      // Store updated users list in localStorage
      localStorage.setItem('mockUsers', JSON.stringify(mockUsers));
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ ...userData, ...newUser })
      // });
      // if (!response.ok) throw new Error('Registration failed');
      // const registeredUser = await response.json();

      return newUser;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
  };

  const changePassword = async (currentPassword: string, newPassword: string): Promise<void> => {
    if (!currentUser) {
      throw new Error('No user logged in');
    }
    
    setIsLoading(true);
    try {
      // In a real app, this would validate the current password against the backend
      if (currentPassword !== 'password') {
        throw new Error('Current password is incorrect');
      }
      
      // In a real app, this would update the password in the backend
      // For now, we'll just show a success message since we're using mock authentication
      toast.success('Password changed successfully!');
    } finally {
      setIsLoading(false);
    }
  };

  // Helper function to get random clinician color
  const getRandomClinicianColor = (): string => {
    const colors = [
      '#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6', 
      '#06B6D4', '#F97316', '#84CC16', '#EC4899', '#6366F1', 
      '#14B8A6', '#F43F5E'
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  };

  const hasPermission = (permission: string): boolean => {
    if (!currentUser) return false;
    
    switch (permission) {
      case 'view_patients':
        return ['admin', 'clinician', 'supervisor'].includes(currentUser.role);
      case 'edit_notes':
        return ['clinician', 'supervisor'].includes(currentUser.role);
      case 'view_billing':
        return ['admin', 'supervisor'].includes(currentUser.role);
      case 'comment_notes':
        return currentUser.role === 'supervisor';
      case 'manage_users':
        return ['admin', 'supervisor'].includes(currentUser.role);
      case 'admin_access':
        return ['admin', 'supervisor'].includes(currentUser.role);
      default:
        return false;
    }
  };

  const canEditNotes = (): boolean => {
    return hasPermission('edit_notes');
  };

  const canViewBilling = (): boolean => {
    return hasPermission('view_billing');
  };

  return (
    <AuthContext.Provider value={{
      currentUser,
      login,
      register,
      logout,
      hasPermission,
      canEditNotes,
      canViewBilling,
      isLoading,
      changePassword,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
